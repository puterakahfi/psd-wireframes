Thanks for downloading.

It’s great that you’re utilizing this, and I encourage you to make your wireframes look like C.Rowe originals. The clients love them. Just don’t try and sell the original collection as something you created, that’s kinda terrible.

And if you’re really digging this kit, give me a holler on twitter or email. Let’s spread the joy of creating good lookin’ wireframes.

———————————————————————————————————————————————————
WWW.THEYCALLMECROWE.COM
TWITTER: @theycallmecrowe
EMAIL: holler@theycallmecrowe.com
———————————————————————————————————————————————————

LICENCE:
This is free, and you can use it where you want. For private and commercial purposes. Do not try and sell this kit.